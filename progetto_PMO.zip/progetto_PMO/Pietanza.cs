﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // classe che istanzia le singole pietanze
    // ordinate dal cliente.
    // Viene applicato il Composite Pattern, la pietanza
    // rappresenta la "foglia" della gerarchia di oggetti
    class Pietanza : IComponent
    {
        // attributi della classe Pietanza
        private string nome;
        private double prezzo;

        // attributo dummy
        private IList<Pietanza> figli = new List<Pietanza>();

        // costruttore della classe pietanza
        public Pietanza(string nome, double prezzo)
        {
            this.nome = nome;
            this.prezzo = prezzo;
        } // fine costruttore

        // proprietà
        public string OttieniNome() => nome;

        // override
        public double OttieniPrezzo() => prezzo;
     
        // metodo dummy
        public void Add(Pietanza c) { }

        // metodo dummy
        public void Remove(Pietanza c) { }

        // metodo dummy
        public Pietanza OttieniFiglio(int indice) { return null; }

        // metodo dummy
        public IEnumerable<Pietanza> OttieniFigli() => figli;
    } // fine classe pietanza
}
