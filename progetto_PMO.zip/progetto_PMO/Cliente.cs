﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    class Cliente
    {
        // attributi di Cliente
        // attributo che contiene l'unica istanza di cliente
        private static Cliente cliente = null;

        // riferimento al cameriere
        public Cameriere mioCameriere = null;

        // attributo contenente lo stato attuale in cui si trova il cliente
        private IStatoCliente statoAttuale = null;

        // costruttore della classe Cliente. Applico il pattern Singleton
        // in modo tale che possa essere istanziata una sola istanza
        // di Cliente
        private Cliente()
        {
            Console.WriteLine("\nBenvenuto nel nostro ristorante!");
            // assegno l'istanza di cameriere al riferimento interno
            mioCameriere = Cameriere.OttieniCameriere();
            // inizializzo lo stato del cliente
            this.statoAttuale = Ordinazione.Istanza;
        } // fine costruttore

        // metodo per ottenere l'unica istanza di cliente
        public static Cliente OttieniCliente()
        {
            if (cliente == null)
                cliente = new Cliente();
            return cliente;
        } // fine metodo OttieniCliente()

        // proprietà statoAttuale
        public IStatoCliente StatoAttuale
        {
            get { return  statoAttuale;  }
            set { statoAttuale = value;  }
        }

        // metodo per Ordinare una pietanza
        public void Ordina()
        {
            StatoAttuale.Ordina(this);
        } // fine metodo Ordina()

        // metodo per attendere la prossima pietanza ( i cuochi cucinano)
        public Pietanza AttendiProssimaPortata()
        {
            Pietanza p;
            p = StatoAttuale.AttendiProssimaPortata(this);
            return p;
        } // fine metodo AttendiProssimaPietanza()

        // metodo per mangiare la pietanza
        public void Mangia(Pietanza p)
        {
            StatoAttuale.Mangia(this, p);
        } // fine metodo Mangia()

        // metodo per chiamare il cameriere per ordinare qualcos'altro
        public void ChiamaCameriere()
        {
            StatoAttuale.ChiamaCameriere(this);
        } // fine metodo ChiamaCameriere()
        
        //metodo per chiedere il conto
        public void ChiediConto()
        {
            StatoAttuale.ChiediConto(this);
        } // fine metodo ChiediConto()

        // metodo per pagare il conto
        public void PagaConto()
        {
            StatoAttuale.PagaConto(this);
        } // fine metodo PagaConto()
    } // fine classe Cliente
}
