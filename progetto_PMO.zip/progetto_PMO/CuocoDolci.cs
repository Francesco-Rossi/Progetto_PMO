﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SimulazioneRistorante
{
    // il cuoco dei dolci è gentile... regala sempre un pezzo di torta
    // al cliente
    class CuocoDolci : Cuoco
    {
        // applico il pattern Singleton
        private static CuocoDolci cuocoDolci = null;
        private CuocoDolci() { }

        // metodo per ottenere l'unica istanza di CuocoDolci
        public static CuocoDolci OttieniCuocoDolci()
        {
            if (cuocoDolci == null)
                cuocoDolci = new CuocoDolci();
            return cuocoDolci;
        } // fine metodo OttieniCuocoDolci()

        // override del metodo astratto della classe base Cucina()
        public override Pietanza Cucina()
        {
            Pietanza p;
            Console.WriteLine("------------------------------------------");
            // cucina il primo ordine presente nella lista di pietanze da cucinare
            Console.WriteLine("Il cuoco dei primi sta cucinando " + PietanzeDaCucinare[0].OttieniNome() + "...");
            // simulazione cuoco che cucina tramite una sleep
            Thread.Sleep(3000);
            Console.WriteLine("...Il cuoco dei primi ha terminato di cucinare " + PietanzeDaCucinare[0].OttieniNome());
            Console.WriteLine("Il cuoco dei dolci ha messo una fetta di torta alle mele in omaggio nel piatto! ");
            p = PietanzeDaCucinare[0];
            // il dolce appena cucinato viene rimosso dalla lista di dolci da cucinare
            PietanzeDaCucinare.RemoveAt(0);
            // il metodo ritorna il dolce appena cucinato
            return p;
        } // fine metodo Cucina()
    } // fine classe CuocoDolci
}