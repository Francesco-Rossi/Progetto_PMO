﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SimulazioneRistorante
{
    // stato di cliente, implementa l'interfaccia IStatoCliente
    class Consumazione : IStatoCliente 
    {
        // applico il pattern Singleton
        private static readonly Consumazione istanza = new Consumazione();
        private Consumazione() { }

        // proprietà per ottenere l'unica istanza di Consumazione
        public static Consumazione Istanza { get => istanza; }

        // operazione invalida per questo stato
        public void Ordina(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public Pietanza AttendiProssimaPortata(Cliente c) => throw new InvalidOperationException();

        // metodo per mangiare la pietanza appena arrivata
        public void Mangia(Cliente c, Pietanza p)
        {
            Console.WriteLine("\nSto mangiando " + p.OttieniNome());
            // simulazione del cliente che mangia tramite una sleep di 4 secondi
            Thread.Sleep(3000);
            Console.WriteLine("\nHo terminato di mangiare " + p.OttieniNome());
            // aggiorno lo stato
            c.StatoAttuale = Attesa.Istanza;
        } // fine metodo Mangia()

        // operazione invalida per questo stato
        public void ChiamaCameriere(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void ChiediConto(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void PagaConto(Cliente c) => throw new InvalidOperationException();

    } // fine classe Consumazione
}
