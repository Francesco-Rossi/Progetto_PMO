﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SimulazioneRistorante
{
    // il cuoco dei secondi è un pò più veloce rispetto agli altri
    class CuocoSecondi : Cuoco
    {
        // applico il pattern Singleton
        private static CuocoSecondi cuocoSecondi = null;
        private CuocoSecondi() { }

        // metodo per ottenere l'unica istanza di CuocoSecondi
        public static CuocoSecondi OttieniCuocoSecondi()
        {
            if (cuocoSecondi == null)
                cuocoSecondi = new CuocoSecondi();
            return cuocoSecondi;
        } // fine metodo OttieniCuocoSecondi()

        // override del metodo astratto della classe base Cucina()
        public override Pietanza Cucina()
        {
            Pietanza p;
            Console.WriteLine("------------------------------------------");
            // cucina il primo ordine presente nella lista di pietanze da cucinare
            Console.WriteLine("Il cuoco dei secondi sta cucinando " + PietanzeDaCucinare[0].OttieniNome() + "...");
            // simulazione cuoco che cucina tramite una sleep
            Thread.Sleep(2000);
            Console.WriteLine("...Il cuoco dei secondi ha terminato di cucinare " + PietanzeDaCucinare[0].OttieniNome());
            p = PietanzeDaCucinare[0];
            // il secondo appena cucinato viene rimosso dalla lista di secondi da cucinare
            PietanzeDaCucinare.RemoveAt(0);
            // il metodo ritorna il secondo appena cucinato
            return p;
        } // fine metodo Cucina()
    } // fine classe CuocoSecondi
}
