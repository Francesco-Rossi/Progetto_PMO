﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    class Cameriere
    {
        // attributi di Cameriere
      
        // Applico il pattern Singleton
        // attributo che contiene l'unica istanza di cameriere
        private static Cameriere cameriere = null;

        // blocknotes del cameriere (contiene l'unica istanza di BlockNotes)
        private BlockNotes mioBlockNotes;

        // riferimento al Menu
        private Menu mioMenu;

        // riferimento ai Cuochi
        private CuocoPrimi mioCuocoPrimi;
        private CuocoSecondi mioCuocoSecondi;
        private CuocoDolci mioCuocoDolci;

        // costruttore della classe Cameriere. Applico il pattern Singleton
        // in modo tale che possa essere istanziata una sola istanza
        // di cameriere
        private Cameriere()
        {
            // inizializzo i riferimenti con le singole istanze delle rispettive classi
            mioBlockNotes = BlockNotes.OttieniBlockNotes();
            mioMenu = Menu.OttieniMenu();
            mioCuocoPrimi = CuocoPrimi.OttieniCuocoPrimi();
            mioCuocoSecondi = CuocoSecondi.OttieniCuocoSecondi();
            mioCuocoDolci = CuocoDolci.OttieniCuocoDolci();
        } // fine costruttore

        // metodo per ottenere l'unica istanza di cameriere
        public static Cameriere  OttieniCameriere()
        {
            if (cameriere == null)
                cameriere = new Cameriere();
            return cameriere;
        } // fine metodo OttieniCameriere()

        // proprietà
        public CuocoPrimi MioCuocoPrimi { get { return mioCuocoPrimi;  } }
        public CuocoSecondi MioCuocoSecondi { get { return mioCuocoSecondi; } }
        public CuocoDolci MioCuocoDolci { get { return mioCuocoDolci; } }
        public BlockNotes MioBlockNotes { get { return mioBlockNotes;  } }
        public Menu MioMenu { get { return mioMenu; } }

        // metodo per mostrare i primi patti e far scegliere al cliente
        // cosa vuole ordinare
        public void mostraPrimi()
        {
            int i = 1;
            int j = 1;
            int scelta = -1;
            // il cameriere mostra i primi piatti e i rispettivi prezzi
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nCameriere : Ecco i nostri primi piatti del giorno, ");
            Console.WriteLine("\nCameriere : Quale primo vuole ordinare? : ");
            foreach (string s in mioMenu.ListaPrimi.Keys)
            {
                Console.WriteLine(i + " -> " + s + " - euro " + mioMenu.ListaPrimi[s]);
                i++;
            }
            Console.WriteLine(i + " -> Niente");

            // il cliente sceglie cosa ordinare
            do
            {
                Console.WriteLine("Digitare il numero corrispondente al primo piatto per ordinarlo");
                try
                {
                    scelta = int.Parse(Console.ReadLine());
                } catch(FormatException e)
                {
                    Console.WriteLine(e + "\nFormato non accettabile, digitare nuovamente.");
                }
            } while (scelta < 1 || scelta > (mioMenu.ListaPrimi.Count + 1));

            // il cameriere scrive l'ordine nel blockNotes
            foreach (string s in mioMenu.ListaPrimi.Keys)
            {
                if (j == scelta)
                {
                    ScriviOrdine(new Pietanza(s, mioMenu.ListaPrimi[s]));
                    // il cuoco dei primi ha una nuova pietanza da cucinare
                    mioCuocoPrimi.aggiungiPietanza(new Pietanza(s, mioMenu.ListaPrimi[s]));
                    Console.WriteLine("Hai ordinato : " + s);
                }
                j++;
            } // fine foreach
            if (scelta == (mioMenu.ListaPrimi.Count+1))
                Console.WriteLine("Non hai ordinato nessun primo");
        } // fine metodo mostraPrimi()

        // metodo per mostrare i secondi patti e far scegliere al cliente
        // cosa vuole ordinare
        public void mostraSecondi()
        {
            int i = 1;
            int j = 1;
            int scelta = -1;
            // il cameriere mostra i secondi piatti e i rispettivi prezzi
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nCameriere : Ecco i nostri secondi piatti del giorno, ");
            Console.WriteLine("\nCameriere : Quale secondo vuole ordinare? : ");
            foreach (string s in mioMenu.ListaSecondi.Keys)
            {
                Console.WriteLine(i + " -> " + s + " - euro " + mioMenu.ListaSecondi[s]);
                i++;
            }
            Console.WriteLine(i + " -> Niente");

            // il cliente sceglie cosa ordinare
            do
            {
                Console.WriteLine("Digitare il numero corrispondente al secondo piatto per ordinarlo");
                try
                {
                    scelta = int.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e + "\nFormato non accettabile, digitare nuovamente.");
                }
            } while (scelta < 1 || scelta > (mioMenu.ListaSecondi.Count + 1));

            // il cameriere scrive l'ordine nel blockNotes
            foreach (string s in mioMenu.ListaSecondi.Keys)
            {
                if (j == scelta)
                {
                    ScriviOrdine(new Pietanza(s, mioMenu.ListaSecondi[s]));
                    // il cuoco dei secondi ha una nuova pietanza da cucinare
                    mioCuocoSecondi.aggiungiPietanza(new Pietanza(s, mioMenu.ListaSecondi[s]));
                    Console.WriteLine("Hai ordinato : " + s);
                }
                j++;
            } // fine foreach
            if (scelta == (mioMenu.ListaSecondi.Count + 1))
                Console.WriteLine("Non hai ordinato nessun secondo.");
        } // fine metodo mostraSecondi()

        // metodo per mostrare i dolci e far scegliere al cliente
        // cosa vuole ordinare
        public void mostraDolci()
        {
            int i = 1;
            int j = 1;
            int scelta = -1;
            // il cameriere mostra i dolci e i rispettivi prezzi
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nCameriere : Ecco i nostri  dolci del giorno, ");
            Console.WriteLine("\nCameriere : Quale dolce vuole ordinare? : ");
            foreach (string s in mioMenu.ListaDolci.Keys)
            {
                Console.WriteLine(i + " -> " + s + " - euro " + mioMenu.ListaDolci[s]);
                i++;
            }
            Console.WriteLine(i + " -> Niente");

            // il cliente sceglie cosa ordinare
            do
            {
                Console.WriteLine("Digitare il numero corrispondente al dolce per ordinarlo");
                try
                {
                    scelta = int.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e + "\nFormato non accettabile, digitare nuovamente.");
                }
            } while (scelta < 1 || scelta > (mioMenu.ListaDolci.Count + 1));

            // il cameriere scrive l'ordine nel blockNotes
            foreach (string s in mioMenu.ListaDolci.Keys)
            {
                if (j == scelta)
                {
                    ScriviOrdine(new Pietanza(s, mioMenu.ListaDolci[s]));
                    // il cuoco dei dolci ha una nuova pietanza da cucinare
                    mioCuocoDolci.aggiungiPietanza(new Pietanza(s, mioMenu.ListaDolci[s]));
                    // il cuoco dei dolci offre sempre una fetta di torta, che verrà
                    // comunque segnalata sul conto
                    ScriviOrdine(new Pietanza("torta alle mele", 0.00));
                    Console.WriteLine("Hai ordinato : " + s);
                }
                j++;
            } // fine foreach
            if (scelta == (mioMenu.ListaDolci.Count + 1))
                Console.WriteLine("Non hai ordinato nessun dolce.");
        } // fine metodo mostraDolci()

        // metodo per mostrare le bevande e far scegliere al cliente
        // cosa vuole ordinare
        public void mostraBevande()
        {
            int i = 1;
            int j = 1;
            int scelta = -1;
            // il cameriere mostra le bevande e i rispettivi prezzi
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nCameriere : Ecco le nostre bevande ");
            Console.WriteLine("\nCameriere : Che cosa vuole ordinare? : ");
            foreach (string s in mioMenu.ListaBevande.Keys)
            {
                Console.WriteLine(i + " -> " + s + " - euro " + mioMenu.ListaBevande[s]);
                i++;
            }
            Console.WriteLine(i + " -> Niente");

            // il cliente sceglie cosa ordinare
            do
            {
                Console.WriteLine("Digitare il numero corrispondente alla bevanda per ordinarla");
                try
                {
                    scelta = int.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e + "\nFormato non accettabile.");
                }
            } while (scelta < 1 || scelta > (mioMenu.ListaBevande.Count + 1));

            // il cameriere scrive l'ordine nel blockNotes
            foreach (string s in mioMenu.ListaBevande.Keys)
            {
                if (j == scelta)
                {
                    ScriviOrdine(new Pietanza(s, mioMenu.ListaBevande[s]));
                    Console.WriteLine("Hai ordinato : " + s);
                    // il cameriere serve immediatamente la bevanda
                    Console.WriteLine("\nIl cameriere ti ha appena portato " + s);
                }
                j++;
            } // fine foreach
            if (scelta == (mioMenu.ListaBevande.Count + 1))
                Console.WriteLine("\nNon hai ordinato nessuna bevanda.");

        } // fine metodo mostraBevande()

        // metodo per scrivere l'ordine
        public void ScriviOrdine(IComponent p)
        {
            mioBlockNotes.aggiungiOrdine(p);
        } // fine metodo ScriviOrdine()

        // metodo per servire gli ordini una volta pronti
        public void ServiOrdine(Pietanza p)
        {
            Console.WriteLine("Il cameriere ti ha appena servito " + p.OttieniNome());
        } // fine metodo ServiOrdine()

        // metodo per stampare il conto
        public void StampaConto()
        {
            int i = 1;
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("Ecco il conto");
            foreach (IComponent p in mioBlockNotes.ListaPietanze)
            {
                Console.WriteLine(i + " -> " + p.OttieniNome() + " - Euro " + p.OttieniPrezzo());
                i++;
            }
            Console.WriteLine("Il totale è : " + mioBlockNotes.CalcolaConto() + " euro");

        } // fine metodo PortaConto()

        // metodo per mostrare il menù del giorno (le singole pietanze vengono
        // scelte casualmente)
        public IComponent MostraMenuDelGiorno()
        {
            IComponent menuDelGiorno = new ComposizionePietanze();
            int i = -1;
            int j = 1;
            Random random = new Random();
            i = random.Next(1, mioMenu.ListaPrimi.Count);
            Console.WriteLine("\nIl menù del giorno prevede: ");
            // viene scelto casualmente il primo piatto del menù del giorno
            foreach(string s in mioMenu.ListaPrimi.Keys)
            {
                if (i == j)
                {
                    Console.WriteLine("Primo -> " + s + " - euro " + (mioMenu.ListaPrimi[s]- 1) + " - sconto 1 euro");
                    menuDelGiorno.Add(new Pietanza(s, mioMenu.ListaPrimi[s] - 1));
                }
                j++;
            }

            i = random.Next(1, mioMenu.ListaSecondi.Count);
            j = 1;
            // viene scelto casualmente il secondo piatto del menù del giorno
            foreach (string s in mioMenu.ListaSecondi.Keys)
            {
                if (i == j)
                {
                    Console.WriteLine("Secondo -> " + s + " - euro " + (mioMenu.ListaSecondi[s]-1) + " - sconto 1 euro");
                    menuDelGiorno.Add(new Pietanza(s, mioMenu.ListaSecondi[s] - 1));
                }
                j++;
            }

            i = random.Next(1, mioMenu.ListaDolci.Count);
            j = 1;
            // viene scelto casualmente il dolce del menù del giorno.
            foreach (string s in mioMenu.ListaDolci.Keys)
            {
                if (i == j)
                {
                    Console.WriteLine("Dolce -> " + s + " - euro " + (mioMenu.ListaDolci[s]-1) + " - sconto 1 euro");
                    menuDelGiorno.Add(new Pietanza(s, mioMenu.ListaDolci[s] - 1));
                }
                j++;
            }
            // il metodo restituisce il menù del giorno appena composto
            return menuDelGiorno;
        } // fine metodo MostraMenuDelGiorno()
    } // fine classe cameriere
}
