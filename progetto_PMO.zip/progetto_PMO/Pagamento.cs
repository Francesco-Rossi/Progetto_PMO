﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // stato di cliente, implementa l'interfaccia IStatoCliente
    class Pagamento : IStatoCliente 
    {
        // applico il pattern Singleton
        private static readonly Pagamento istanza = new Pagamento();
        private Pagamento() { }

        // proprietà per ottenere l'unica istanza di Pagamento
        public static Pagamento Istanza { get => istanza; }

        // operazione invalida per questo stato
        public void Ordina(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public Pietanza AttendiProssimaPortata(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void ChiamaCameriere(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void Mangia(Cliente c, Pietanza p) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void ChiediConto(Cliente c) => throw new InvalidOperationException();

        // metodo per pagare il conto e lasciare il locale.
        // Lo stato non viene più aggiornato
        public void PagaConto(Cliente c)
        {
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nHo pagato il conto...");
            Console.WriteLine("\nSto lasciando il locale.");
        } // fine metodo PagaConto()
    } // fine classe Pagamento
}
