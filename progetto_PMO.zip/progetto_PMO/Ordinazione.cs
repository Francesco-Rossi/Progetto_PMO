﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // stato di cliente, implementa l'interfaccia IStatoCliente
    class Ordinazione : IStatoCliente
    {
        // il menù del giorno può essere acquistato solo all'inizio della simulazione

        // applico il pattern Singleton
        private static readonly Ordinazione istanza = new Ordinazione();
        private Ordinazione() { }

        // proprietà per ottenere l'unica istanza di Ordinazione
        public static Ordinazione Istanza { get => istanza; }

        // metodo per ordinare la prima volta
        public void Ordina(Cliente c)
        {
            int scelta = -1;
            IComponent menuDelGiorno;
            Console.WriteLine("\nIl menù del giorno prevede un primo, un secondo e "
                 + "un dolce, con un piccolo sconto su ogni portata");
            menuDelGiorno = c.mioCameriere.MostraMenuDelGiorno();
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nCameriere : Vuole ordinare il menù del giorno o singolarmente? ");
            do
            {
                Console.WriteLine("Digita 1 se vuoi ordinare il menù del giorno ...");
                Console.WriteLine("Digita 2 se vuoi ordinare singolarmente");
                try
                {
                    scelta = int.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e + "\nFormato non accettabile, digitare nuovamente.");
                }
            } while (scelta < 1 || scelta > 2);

            if (scelta == 1)
            {
                Console.WriteLine("\nHai ordinato il menù del giorno!");
                c.mioCameriere.ScriviOrdine(menuDelGiorno);
                // i cuochi hanno nuove pietanze da cucinare
                c.mioCameriere.MioCuocoPrimi.aggiungiPietanza(menuDelGiorno.OttieniFiglio(0));
                c.mioCameriere.MioCuocoSecondi.aggiungiPietanza(menuDelGiorno.OttieniFiglio(1));
                c.mioCameriere.MioCuocoDolci.aggiungiPietanza(menuDelGiorno.OttieniFiglio(2));
                c.mioCameriere.mostraBevande();
            }
            if (scelta == 2)
            {
                Console.WriteLine("\nVuoi ordinare singolarmente le portate.");
                c.mioCameriere.mostraPrimi();
                c.mioCameriere.mostraSecondi();
                c.mioCameriere.mostraDolci();
                c.mioCameriere.mostraBevande();
            }

            // aggiorno lo stato
            c.StatoAttuale = Attesa.Istanza;
        } // fine metodo Ordina()

        // operazione invalida per questo stato
        public Pietanza AttendiProssimaPortata(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void Mangia(Cliente c, Pietanza p) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void ChiamaCameriere(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void ChiediConto(Cliente c) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void PagaConto(Cliente c) => throw new InvalidOperationException();

    } // fine classe Ordinazione
}
