﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // Viene applicato il Composite Pattern
    class ComposizionePietanze : IComponent
    {
        // attributo che contiene la lista di pietanze.
        // è un composite pattern rivisitato in quanto la composizione di pietanze,
        // cioè il menù del giorno, non può avere come figli altre composizioni
        private IList<Pietanza> figli = new List<Pietanza>();
        private  double prezzo;
        private string nome = "Menù del giorno";

        public string OttieniNome() => nome;
        public void Add(Pietanza c)
        {
            figli.Add(c);
            prezzo += c.OttieniPrezzo();
        }
        public void Remove(Pietanza c) => figli.Remove(c);
        public IEnumerable<Pietanza> OttieniFigli() => figli;

        public Pietanza OttieniFiglio(int indice)
        {
            if (indice < figli.Count)
                return figli[indice];
            return null;
        } // fine metodo OttieniFiglio()

        public double OttieniPrezzo()
        {
            return prezzo;
        } // fine metodo OttieniPrezzo()

    } // fine classe ComposizionePietanze
}
