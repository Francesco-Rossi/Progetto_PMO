﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // interfaccia per implementare il Composite pattern
    interface IComponent
    {
        // metodo per ottenere il nome
        string OttieniNome();

        // metodo per ottenere il prezzo
        double OttieniPrezzo();
        // metodo per aggiungere qualcosa alla composizione
        void Add(Pietanza c);
        // metodo per rimuovere qualcosa dalla composizione
        void Remove(Pietanza c);
        // metodo per ottenere un singolo figlio
        Pietanza OttieniFiglio(int indice);
        // metodo per ottenere tutti i figli
        IEnumerable<Pietanza> OttieniFigli();
    } // fine interfaccia Component
}
