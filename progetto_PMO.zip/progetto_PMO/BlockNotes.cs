﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // classe BlockNotes che riporta tutte le pietanze ordinate 
    // dal cliente e che calcola il prezzo da pagare
    class BlockNotes
    {
        // attributi di BlockNotes

        // lista di pietanze ordinate dall'utente
        // la lista è formata da "IComponent" perchè
        // potrebbe contenere, oltre che alle pietanze singole,
        // anche il menù del giorno (ComposizionePietanze)
        private List<IComponent> listaPietanze = new List<IComponent>();

        // attributo che contiene l'unica istanza di BlockNotes
        private static BlockNotes blocknotes = null;

        // costruttore della classe BlockNotes. Applico il pattern Singleton
        // in modo tale che possa essere istanziata una sola istanza
        // di BlockNotes
        private BlockNotes() { } 

        // proprietà
        public List<IComponent> ListaPietanze { get { return listaPietanze;  } }

        // metodo per ottenere l'unica istanza di BlockNotes
        public static BlockNotes OttieniBlockNotes()
        {
            if (blocknotes == null)
                blocknotes = new BlockNotes();
            return blocknotes;
        } // fine metodo OttieniBlockNotes()

        // metodo per aggiungere una pietanza alla lista delle pietanze ordinate dal cliente.
        // può essere aggiunto anche il "Menù del giorno" ordinato dal cliente
        public void aggiungiOrdine(IComponent p)
        {
            this.listaPietanze.Add(p);
        } // fine metodo scriviOrdine()

        // metodo per calcolare il conto da pagare
        public double CalcolaConto()
        {
            double conto = 0;
            // tutti gli elementi in listaPietanze, singoli o menù del giorno,
            // vengono trattati allo stesso modo, richiamando il metodo
            // OttieniPrezzo() per calcolare il conto.
            foreach (IComponent p in listaPietanze)
                conto += p.OttieniPrezzo();
            return conto;
        } // fine metodo calcoloConto()
    } // fine classe BlockNotes
}
