﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SimulazioneRistorante
{
    class Menu
    {
        // lista attributi della classe Menu
        // viene utilizzato un Dictionary per associare ad ogni pietanza (string)
        // un prezzo(double)
        private Dictionary<string, double> listaPrimi = new Dictionary<string, double>();
        private Dictionary<string, double> listaSecondi = new Dictionary<string, double>();
        private Dictionary<string, double> listaDolci = new Dictionary<string, double>();
        private Dictionary<string, double> listaBevande = new Dictionary<string, double>();
        // attributo interno che contiene i file passati come parametro di input alla funzione Main()
        private static string[] args = null;

        // Utilizzo il pattern Singleton affinché possa essere istanziata
        // una sola istanza di Menù
        // attributo che contiene l'unica istanza di Menu
        private static Menu menu = null;

        // costruttore privato della classe menu
        private Menu()
        {
            // stringhe per contenere le righe lette dai file
            String stringaPrimi, stringaSecondi, stringaDolci, stringaBevande;
            StreamReader srPrimi, srSecondi, srDolci, srBevande; // identificatori per il file stream reader
            // controlli sull'esistenza dei file
            Console.WriteLine("Controllo esistenza dei file...");
            if (File.Exists(args[0]) && File.Exists(args[1]) && File.Exists(args[2]) && File.Exists(args[3]))
                Console.WriteLine("...Tutti i file sono stati trovati correttamente! ");
            else
            {
                Console.WriteLine("Errore nella ricerca dei file");
                // termino il processo ritornando un valore di errore al sistema operativo
                Environment.Exit(1);
            }
                
            // apro il file primi.txt
            srPrimi   = File.OpenText(args[0]);

            // riempio il dictionary listaPrimi con portate e rispettivi prezzi 
            while (!srPrimi.EndOfStream)
            {
                stringaPrimi    = srPrimi.ReadLine();
                // divido ogni riga in due parti : la prima contiene il nome, la seconda il prezzo
                string[] rigaSplittata = stringaPrimi.Split(' ');
                // associo al nome di ogni piatto del menu il prezzo, il quale viene convertito in double
                this.listaPrimi.Add(rigaSplittata[0], double.Parse(rigaSplittata[1]));
            }
            // chiudo il file primi.text
            srPrimi.Close();

            // -------------------------------------------------

            // apro il file secondi.txt
            srSecondi = File.OpenText(args[1]);

            // riempio il dictionary listaSecondi con portate e rispettivi prezzi 
            while (!srSecondi.EndOfStream)
            {
                stringaSecondi = srSecondi.ReadLine();
                // divido ogni riga in due parti : la prima contiene il nome, la seconda il prezzo
                string[] rigaSplittata = stringaSecondi.Split(' ');
                // associo al nome di ogni piatto del menu il prezzo, il quale viene convertito in double
                this.listaSecondi.Add(rigaSplittata[0], double.Parse(rigaSplittata[1]));
            }
            // chiudo il file secondi.text
            srSecondi.Close();

            // -------------------------------------------------

            // apro il file dolci.txt
            srDolci = File.OpenText(args[2]);

            // riempio il dictionary listaDolci con portate e rispettivi prezzi 
            while (!srDolci.EndOfStream)
            {
                stringaDolci = srDolci.ReadLine();
                // divido ogni riga in due parti : la prima contiene il nome, la seconda il prezzo
                string[] rigaSplittata = stringaDolci.Split(' ');
                // associo al nome di ogni piatto del menu il prezzo, il quale viene convertito in double
                this.listaDolci.Add(rigaSplittata[0], double.Parse(rigaSplittata[1]));
            }
            // chiudo il file Dolci.text
            srDolci.Close();

            // -------------------------------------------------

            // apro il file bevande.txt
            srBevande = File.OpenText(args[3]);

            // riempio il dictionary listaBevande con portate e rispettivi prezzi 
            while (!srBevande.EndOfStream)
            {
                stringaBevande = srBevande.ReadLine();
                // divido ogni riga in due parti : la prima contiene il nome, la seconda il prezzo
                string[] rigaSplittata = stringaBevande.Split(' ');
                // associo al nome di ogni piatto del menu il prezzo, il quale viene convertito in double
                this.listaBevande.Add(rigaSplittata[0], double.Parse(rigaSplittata[1]));
            }
            // chiudo il file Bevande.text
            srBevande.Close();

        } // fine costruttore Menu()

        // metodo per ritornare l'unica istanza di Menu
        public static Menu OttieniMenu()
        {
            // istanzio Menu se non è stato ancora istanziato
            if (menu == null)
               menu = new Menu();
            return menu;
        } // fine metodo ottieniMenu()

        // metodo per fissare l'argomento del Main() "args" una volta per tutte all'attributo
        // interno di Menu
        public static void fissaArgs(string[] argInput)
        {
            if (args == null)
                args = argInput;
        } // fine metodo fissaArgs()

        // proprietà
        public  Dictionary<string, double> ListaPrimi
        {
            get { return listaPrimi; }
        }
        public Dictionary<string, double> ListaSecondi
        {
            get { return listaSecondi; }
        }
        public Dictionary<string, double> ListaDolci
        {
            get { return listaDolci; }
        }
        public Dictionary<string, double> ListaBevande
        {
            get { return listaBevande; }
        }
    } // fine classe Menu
}
