﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SimulazioneRistorante
{
    // il cuoco dei primi è un pò lento rispetto agli altri
    class CuocoPrimi : Cuoco
    {
        // applico il pattern Singleton
        private static CuocoPrimi cuocoPrimi = null;
        private CuocoPrimi() { }

        // metodo per ottenere l'unica istanza di CuocoPrimi
        public static CuocoPrimi OttieniCuocoPrimi()
        {
            if (cuocoPrimi == null)
                cuocoPrimi = new CuocoPrimi();
            return cuocoPrimi;
        } // fine metodo OttieniCuocoPrimi()


        // override del metodo astratto della classe base Cucina()
        public override Pietanza Cucina()
        {
            Pietanza p;
            Console.WriteLine("------------------------------------------");
            // cucina il primo ordine presente nella lista di pietanze da cucinare
            Console.WriteLine("Il cuoco dei primi sta cucinando " + PietanzeDaCucinare[0].OttieniNome() + "...");
            // simulazione cuoco che cucina tramite una sleep
            Thread.Sleep(4000);
            Console.WriteLine("..Il cuoco dei primi ha terminato di cucinare " + PietanzeDaCucinare[0].OttieniNome());
            p = PietanzeDaCucinare[0];
            // il primo appena cucinato viene rimosso dalla lista di primi da cucinare
            PietanzeDaCucinare.RemoveAt(0);
            // il metodo ritorna il primo appena cucinato
            return p;
        } // fine metodo Cucina()
    } // fine classe CuocoPrimi
}
