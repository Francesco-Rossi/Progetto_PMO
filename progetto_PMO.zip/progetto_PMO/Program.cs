﻿using System;
using System.IO;

namespace SimulazioneRistorante
{
    class Program
    {
        // PROGETTO PMO 
        // Francesco Pio Rossi
        // matricola : 298356
        // SIMULAZIONE RISTORANTE
        static void Main(string[] args)
        {
            // controlli preliminari sui parametri di
            // ingresso della funzione Main()
            if(args.Length != 4)
            {
                Console.Error.WriteLine("Errore di inizializzazione. Specificare i file di input del programma");
                // termino il processo ritornando un valore di errore al sistema operativo
                Environment.Exit(1);
            }
            // fisso "args" nella classe Menù
            Menu.fissaArgs(args);
            // creo l'unica istanza di Menu
            Menu menu = Menu.OttieniMenu();

            Console.WriteLine("INIZIO SIMULAZIONE RISTORANTE");

            // creo l'unica istanza di Cliente
            Cliente cliente = Cliente.OttieniCliente();
            // creo l'unica istanza di Cameriere, il cui costruttore crea
            // l'unica istanza di BlockNotes
            Cameriere cameriere = Cameriere.OttieniCameriere();

            // creo le istanze dei cuochi, un cuoco per i primi, uno per
            // i secondi e uno per i dolci
            Cuoco cuocoPrimi = CuocoPrimi.OttieniCuocoPrimi();
            Cuoco cuocoSecondi = CuocoSecondi.OttieniCuocoSecondi();
            CuocoDolci cuocoDolci = CuocoDolci.OttieniCuocoDolci();

            string scelta = " ";
            Pietanza piatto  = null;

            // il cliente Ordina
            cliente.Ordina();
            do
            {
                // il cliente attende la prossima portata (i cuochi stanno cucinando).
                // il metodo ritorna il piatto appena cucinato
                piatto = cliente.AttendiProssimaPortata();
                // è arrivata la portata, il cliente mangia
                cliente.Mangia(piatto);
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("\nPremi 1 se vuoi ordinare altro, premi qualsiasi tasto se vuoi continuare la simulazione");
                scelta = Console.ReadLine();
                if (scelta == "1")
                {
                    Console.WriteLine("Vuoi ordinare altro, quindi hai chiamato il cameriere");
                    cliente.ChiamaCameriere();
                }
                else
                    Console.WriteLine("Non hai chiamato il cameriere");

            } while ((cuocoPrimi.PietanzeDaCucinare.Count != 0)|| (cuocoSecondi.PietanzeDaCucinare.Count != 0)
                || (cuocoDolci.PietanzeDaCucinare.Count != 0));

             // il cliente chiede il conto
             cliente.ChiediConto();
             cliente.PagaConto();
             Console.WriteLine("SIMULAZIONE TERMINATA");
        } // fine metodo Main
    } // fine classe Program
}
