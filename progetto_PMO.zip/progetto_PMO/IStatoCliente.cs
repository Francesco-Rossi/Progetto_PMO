﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // interfaccia che determina lo stato in cui si trova il cliente per
    // applicare il pattern State
    interface IStatoCliente
    {
        void Ordina(Cliente c);
        void ChiamaCameriere(Cliente c);
        void Mangia(Cliente c, Pietanza p);
        void ChiediConto(Cliente c);
        Pietanza AttendiProssimaPortata(Cliente c);
        void PagaConto(Cliente c);
        
    } // fine interfaccia IStatoCliente
}
