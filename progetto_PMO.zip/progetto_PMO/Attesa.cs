﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // stato di cliente, implementa l'interfaccia IStatoCliente
    class Attesa : IStatoCliente
    {
        // applico il pattern Singleton
        // attributo privato e statico per contenere l'unica istanza della classe Attesa
        private static readonly Attesa istanza = new Attesa();

        // costruttore privato
        private Attesa() { }

        // proprietà per ottenere l'unica istanza di Attesa
        public static Attesa Istanza { get => istanza; }

        // operazione invalida per questo stato
        public void Ordina(Cliente c) => throw new InvalidOperationException();

        // operazione nella quale il cliente attende dopo aver ordinato.
        // Durante l'attesa i cuochi cucinano
        public Pietanza AttendiProssimaPortata(Cliente c)
        {
            // Si controlla prima se c'è qualche primo da cucinare,
            // se non c'è, si passa ai secondi, sennò ai dolci.
            Pietanza p = null; 
            if (c.mioCameriere.MioCuocoPrimi.PietanzeDaCucinare.Count > 0)
            {
                p = c.mioCameriere.MioCuocoPrimi.Cucina();
                c.mioCameriere.ServiOrdine(p);
            } else if (c.mioCameriere.MioCuocoSecondi.PietanzeDaCucinare.Count > 0)
            {
                p = c.mioCameriere.MioCuocoSecondi.Cucina();
                c.mioCameriere.ServiOrdine(p);
            } else if (c.mioCameriere.MioCuocoDolci.PietanzeDaCucinare.Count > 0)
            {
                p = c.mioCameriere.MioCuocoDolci.Cucina();
                c.mioCameriere.ServiOrdine(p);
            }
            // aggiorno lo stato
            c.StatoAttuale = Consumazione.Istanza;
            // il metodo restituisce la portata appena cucinata
            return p;
        } // fine metodo AttendiProssimaPortata()

        // operazione per chiamare il cameriere per ordinare qualcos'altro
        // durante l'attesa
        public void ChiamaCameriere(Cliente c)
        {
            // il cliente sceglie se vuole ordinare un primo, un secondo,
            // un dolce o qualcosa da bere
            string scelta = "-1";
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("\nPremi 1 se vuoi ordinare un primo");
            Console.WriteLine("\nPremi 2 se vuoi ordinare un secondo");
            Console.WriteLine("\nPremi 3 se vuoi ordinare una dolce");
            Console.WriteLine("\nPremi 4 se vuoi ordinare una bevanda");
            Console.WriteLine("\nPremi un qualsiasi tasto per cambiare idea e non ordinare più nulla.");
            scelta = Console.ReadLine();
            if (scelta == "1")
                c.mioCameriere.mostraPrimi();
            else if (scelta == "2")
                c.mioCameriere.mostraSecondi();
            else if (scelta == "3")
                c.mioCameriere.mostraDolci();
            else if (scelta == "4")
                c.mioCameriere.mostraBevande();
            else
                Console.WriteLine("Hai cambiato idea, non ordini più nulla.");
            // aggiorno lo stato
            c.StatoAttuale = Attesa.Istanza;
        } // fine metodo ChiamaCameriere()

        // metodo per chiedere il conto dopo aver terminato di mangiare tutte le portate
        public void ChiediConto(Cliente c)
        {
            c.mioCameriere.StampaConto();
            // aggiorno lo stato
            c.StatoAttuale = Pagamento.Istanza;
        } // fine metodo ChiediConto()

        // operazione invalida per questo stato
        public void Mangia(Cliente c, Pietanza p) => throw new InvalidOperationException();

        // operazione invalida per questo stato
        public void PagaConto(Cliente c) => throw new InvalidOperationException();
    } // fine classe Attesa
}
