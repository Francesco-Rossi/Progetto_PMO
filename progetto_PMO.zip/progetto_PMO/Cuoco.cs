﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimulazioneRistorante
{
    // classe base astratta che non può essere istanziata
    abstract class Cuoco
    {
        // attributi

        // ogni cuoco ha la propria lista di pietanze che deve cucinare
        private List<Pietanza> pietanzeDaCucinare = new List<Pietanza>();

        // metodo per cucinare un piatto.
        // metodo astratto, ne viene fatto l'overriding nelle classi derivate
        public abstract Pietanza Cucina();

        // proprietà
        public List<Pietanza> PietanzeDaCucinare { get { return pietanzeDaCucinare; } }
        
        // metodo per aggiungere una pietanza da cucinare
        public void aggiungiPietanza(Pietanza p)
        {
            pietanzeDaCucinare.Add(p);
        } // fine metodo aggiungiPietanza()

    } // fine classe cuoco
}
